<?php
error_reporting(E_ALL | E_STRICT);
require_once __DIR__.'/../vendor/autoload.php';
require_once __DIR__.'/Authy/TestCase.php';
