<?php

$test_api_key = "bf12974d70818a08199d17d5e2bae630";
$test_api_host = "http://sandbox-api.authy.com";
