authy-php Changelog
====================

[2019-04-08] Version 3.0.5
----------------------------
- Added CHANGES.md
- Updating TravisCI link
